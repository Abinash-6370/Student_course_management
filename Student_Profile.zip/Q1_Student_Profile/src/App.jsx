import Student from "./components/Student";

function App() {
  return (
    <main className="app">
      <section className="hero">
        <p className="eyebrow">React Practical 01</p>
        <h1>Student Profile Directory</h1>
        <p className="subtitle">
          A simple demonstration of functional components, props and JSX.
        </p>
      </section>

      <section className="student-grid">
        <Student
          name="Omm Abinash Barik"
          course="B.Tech CSE (AI & ML)"
          college="GIET University Student"
        />
        <Student
          name="Aarav Sharma"
          course="B.Tech Computer Science"
          college="SOA University Student"
        />
      </section>
    </main>
  );
}

export default App;
